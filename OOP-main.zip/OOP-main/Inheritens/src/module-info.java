/**
 * 
 */
/**
 * @author Bayu Danu Artha
 *
 */
module Inheritens {
}